
package Vista;

import Modelo.Bitacora;
import Modelo.Caso;
import Modelo.Detective;
import Modelo.Direccion;
import Modelo.Sospechoso;

public class Principal {
    public static void main(String[] args) {
        
        //********************************Detectives******************************************
        Detective detective1 = new Detective(87984, "Roberto Juan", "Roca Fierro", 6, "");
        Detective detective2 = new Detective(89751, "Camilo Jesus", "Tamallo Parra", 4, "");
        Detective detective3 = new Detective(54798, "Maria Cammila", "Rodriguz Quintero", 2, "");
        Detective detective4 = new Detective(59867, "Juan Gullermo", "Palacio Ruiz", 5, "");
        
        //********************************Direcciones********************************************
        Direccion direccion1 = new Direccion("Calle 7 Numero 33-23 El dangon", 8, "El dangon","Valledupar","cesar", "Colombia");
        Direccion direccion2 = new Direccion("calle 5 Numero 22-65 Mocua", 6,"Mocua","Valledupar","Cesar", "Colombia");
        Direccion direccion3 = new Direccion("cr 14-54 san jorge ",9 ,"wila","Popayan","Cauca", "Colombia");
        Direccion direccion4 = new Direccion("calle 24 numero 55-24 ",3 ,"Frandia","Popayan","Cauca", "Colombia");
        Direccion direccion5 = new Direccion("calle 54 numero 78-25 ",15 ,"Frandia","Popayan","Cauca", "Colombia");
        Direccion direccion6 = new Direccion("calle 34 numero 34-26 ",27, "Las flores","Flin", "goro", "Colombia ");
        Direccion direccion7 = new Direccion("cr 3-13 Wacho ",4, "Los angeles","stemblr", "tunja", "Colombia ");
        
        //********************************Sospechosos*******************************************
        Sospechoso sospechoso1 = new Sospechoso(4561237,"Jhonatan","Parca",50,"Hombre robusto/ojos cafes oscuros/calvo/de unos 2.15 metroas de altura", direccion1);
        Sospechoso sospechoso2 = new Sospechoso(7896521,"Daniel","Borra",29,"Hombre delgado/ojos cafes /cabello negro/de 1.70 metroas de altura", direccion2);
        Sospechoso sospechoso3 = new Sospechoso(3569874,"Yurani","Chacha",36,"Mujer delgada/ojos grises /cabello largo castaño /de 1.60 metroas de altura",direccion3);
        Sospechoso sospechoso4 = new Sospechoso(6564563,"Brayan","El brayan",38, "Hombre delgado/ojos cafe oscuros /cabello castaño /de 1.70 metroas de altura", direccion4);
        Sospechoso sospechoso5 = new Sospechoso(5877896, "Wily", "Waco", 35, "Hombre delgado/ojos azules /cabello rubio /de 1.78 metroas de altura", direccion5);
        
        Sospechoso[] caso1Sospechoso = {sospechoso1,sospechoso2};
        Sospechoso[] caso2Sospechoso = {sospechoso3,sospechoso4,sospechoso5};
       
        //*********************************Bitacoras********************************************
        Bitacora bitacora1 = new Bitacora(""," Inicio el caso hay multiples pistas emos avanzado "+"un poco sin embargo aun hay que atar algunos cabos sueltos  uno de los sospechosos nos ha dado inforacion crucial para la solucion de este caso el caso Riofrio sigue en proceso pero ya muy serca de su solucion");
        Bitacora bitacora2 = new Bitacora("","El caso se resolvió con éxito");
        
        Caso caso1 = new Caso (46879, "Cadaber encontrado en el rio", "B", "Riofrio", detective4, caso1Sospechoso, bitacora1);
        Caso caso2 = new Caso (23548, "Cuerpo encontrado en una habitacion de un motel", "C","Motsex", detective1, caso2Sospechoso, bitacora2 );
        System.out.println(caso1);
        System.out.println(caso2);
    }
    
    
    
    
}
