
package Modelo;

public class Detective {
    private int numId;
    private String nombres;
    private String apellidos;
    private int añosXp;
    private String capasitadoTpCase;

    public Detective() {
        
    }
    
    public Detective(int numId, String nombres, String apellidos, int añosXp, String capasitadoTpCase) {
        this.numId = numId;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.añosXp = añosXp ;
        this.capasitadoTpCase = capasitadoTpCase;
    }

    public int getNumId() {
        return numId;
    }

    public void setNumId(int numId) {
        this.numId = numId;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public int getAñosXp() {
        return añosXp;
    }

    public void setAñosXp(int añosXp) {
        this.añosXp = añosXp;
    }

    public String getCapasitadoTpCase() {
        return capasitadoTpCase;
    }

    public void setCapasitadoTpCase(String capasitadoTpCase) {
        this.capasitadoTpCase = capasitadoTpCase;
    }

    @Override
    public String toString(){
        return "\n\nDatos Detective"+"\nID: "+this.getNumId()+"\nNombre: "+this.getNombres()
                +"\nApellido: "+this.getApellidos()+"\nAños de Experiencia: "+this.getAñosXp();
    }
    
}
