
package Modelo;

public class Sospechoso {
    
    private int numId;
    private String nombre;
    private String alias;
    private int edad;
    private String descrpfisica;
    
     public Sospechoso() {
        
    }

    public Sospechoso(int numId, String nombre, String alias, int edad, String descrpfisica, Direccion direccion_conocida) {
        this.numId = numId;
        this.nombre = nombre;
        this.alias = alias;
        this.edad = edad;
        this.descrpfisica = descrpfisica;
    }

    public int getNumId() {
        return numId;
    }

    public void setNumId(int numId) {
        this.numId = numId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getDescrpfisica() {
        return descrpfisica;
    }

    public void setDescrpfisica(String descrpfisica) {
        this.descrpfisica = descrpfisica;
    }
    
    @Override
    public String toString(){
        return "\n\nDatos Sospechoso:"+"\nNumero ID: "+this.getNumId()+"\nNombre: "+this.getNombre()
              +"\nAlias: "+this.getAlias()+"\nedad: "+this.getEdad()+"\nDescipcion: "+this.getDescrpfisica();
    }
    
}
