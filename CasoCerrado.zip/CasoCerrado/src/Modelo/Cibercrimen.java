
package Modelo;

public class Cibercrimen {
    
    private String lineaAsociada;

    public Cibercrimen() {
    }
    public Cibercrimen(String lineaAsociada) {
        this.lineaAsociada = lineaAsociada;
    }

    public String getLineaAsociada() {
        return lineaAsociada;
    }

    public void setLineaAsociada(String lineaAsociada) {
        this.lineaAsociada = lineaAsociada;
    }
 
}
