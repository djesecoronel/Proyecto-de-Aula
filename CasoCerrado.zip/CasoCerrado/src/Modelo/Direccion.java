
package Modelo;

public class Direccion {
    
    private String direcConocida;
    private int numVivienda;
    private String localidad;
    private String ciudad;
    private String departaento; 
    private String pais;

    public Direccion() {
    }

    public Direccion(String direcConocida, int numVivienda, String localidad, String ciudad, String departaento, String pais) {
        this.direcConocida = direcConocida;
        this.numVivienda = numVivienda;
        this.localidad = localidad;
        this.ciudad = ciudad;
        this.departaento = departaento;
        this.pais = pais;
    }

    public String getDirecConocida() {
        return direcConocida;
    }

    public void setDirecConocida(String direcConocida) {
        this.direcConocida = direcConocida;
    }

    public int getNumVivienda() {
        return numVivienda;
    }

    public void setNumVivienda(int numVivienda) {
        this.numVivienda = numVivienda;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getDepartaento() {
        return departaento;
    }

    public void setDepartaento(String departaento) {
        this.departaento = departaento;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    
    
    @Override
    public String toString(){
        return "Direccion conocida" + this.getDirecConocida() + "Numero de vivienda: " + 
                this.getNumVivienda()+"Localidad: "+this.getLocalidad() + "\nCiudad: " +
                this.getCiudad() +"\nDepartamento: "+this.getDepartaento()+"\nPaís: "+this.getPais();
    }
}
