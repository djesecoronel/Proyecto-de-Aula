
package Modelo;

public class Narcoticos {
    
    private String info;

    public Narcoticos() {
    }

    public Narcoticos(String info) {
        this.info = info;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}
