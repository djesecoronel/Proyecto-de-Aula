
package Modelo;

import java.util.Arrays;

public class Caso {
     private int numCaso;
    private String descripCase;
    private String codigoPrioridad;
    private String nombreClave;
    private Detective detective;
    private Sospechoso[] sospechoso;
    private Bitacora info;
    
    public Caso() {
          
    }

    public Caso(int numCaso, String descripCase, String codigoPrioridad, String nombreClave, Detective detective, Sospechoso[] sospechoso, Bitacora info) {
        this.numCaso = numCaso;
        this.descripCase = descripCase;
        this.codigoPrioridad = codigoPrioridad;
        this.nombreClave = nombreClave;
        this.detective = detective;
        this.sospechoso = sospechoso;
        this.info = info;
    }

    public int getNumCaso() {
        return numCaso;
    }

    public void setNumCaso(int numCaso) {
        this.numCaso = numCaso;
    }

    public String getDescripCase() {
        return descripCase;
    }

    public void setDescripCase(String descripCase) {
        this.descripCase = descripCase;
    }

    public String getCodigoPrioridad() {
        return codigoPrioridad;
    }

    public void setCodigoPrioridad(String codigoPrioridad) {
        this.codigoPrioridad = codigoPrioridad;
    }

    public String getNombreClave() {
        return nombreClave;
    }

    public void setNombreClave(String nombreClave) {
        this.nombreClave = nombreClave;
    }

    public Detective getDetective() {
        return detective;
    }

    public void setDetective(Detective detective) {
        this.detective = detective;
    }

    public Sospechoso[] getSospechoso() {
        return sospechoso;
    }

    public void setSospechoso(Sospechoso[] sospechoso) {
        this.sospechoso = sospechoso;
    }

    public Bitacora getInfo() {
        return info;
    }

    public void setInfo(Bitacora info) {
        this.info = info;
    }

    
    
    @Override
   public String toString (){
       return "\nDatos Caso"+"\nNúmero ID del caso: "+this.getNumCaso()+"\nDescripción: "+this.getDescripCase()
               +"\nCódigo de prioridad: "+this.getCodigoPrioridad()+"\nDetective Asignado: "+this.getDetective()
               +"\n\nNombre Clave: "+this.getNombreClave()+"\nLista de Sospechosos: "+Arrays.toString(this.getSospechoso())
               +this.getInfo();
   }
    
}
