 
package Modelo;

public class Bitacora {
    
    private String feIngreso;
    private String info;
    
    public Bitacora(){
        
    }

    public Bitacora(String feIngreso, String info) {
        this.feIngreso = feIngreso;
        this.info = info;
    }

    public String getFeIngreso() {
        return feIngreso;
    }

    public void setFeIngreso(String feIngreso) {
        this.feIngreso = feIngreso;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
    
    @Override
    public String toString(){
        return "\n\nBitácora de la investigación: "+this.getFeIngreso()+"\nInformacion "
                + "correspondiente: "+this.getInfo();
    }
    
}
